<?php
$_fp = fopen("php://stdin", "r");

for($i=1; $i<=50; $i++){
	$check_Foo = $i%3;
	$check_Bar = $i%5;
	$print = "";
	
	if($check_Foo == 0)
		$print .= "Foo";
	if($check_Bar == 0)
		$print .= "Bar";
	
	
	if($print == "")
		echo $i;
	else
		echo $print;
	
	echo "\n";
	
}
?>